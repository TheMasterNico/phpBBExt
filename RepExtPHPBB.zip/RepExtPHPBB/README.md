# Reputation System

## Installation

Copy the extension to phpBB/ext/TheMasterNico/RepExtPHPBB

Go to "ACP" > "Customise" > "Extensions" and enable the "Reputation System" extension.

## License

[GPLv2](LICENCE)
